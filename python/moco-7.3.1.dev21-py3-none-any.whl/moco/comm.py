import struct

from moco.packet import CDataPacket, make_packet
from moco.util.zmqsocket import ZmqSender, ZmqListener
import logging
logger = logging.getLogger(__name__)


class Comm(object):
    def __init__(self, serial, config=None, host='localhost', receive_port=6510, send_port=6511, receive_callback=None):
        self.name = "{}".format(serial)
        self.serial_int = struct.pack("i", serial)
        self._packet_for_receive = CDataPacket()
        self._packet_for_send = CDataPacket()
        self._last_received_packet = None
        self.sender = ZmqSender(send_port, host)
        if serial != 0xFEFE:
            self.receiver = ZmqListener(receive_port, self.got_data, host, self.name,
                                        topic=self.serial_int)
        else:
            self.receiver = ZmqListener(receive_port, self.got_data, host, self.name)
        self.receive_callback = receive_callback
        self.config = config

    def got_data(self, msg):
        serial = msg[0]
        data = msg[1]
        self._last_received_packet = CDataPacket(raw=data, packet=self._packet_for_receive)
        if self.receive_callback:
            self.receive_callback(self._last_received_packet)

    def last_received_packet(self):
        return self._last_received_packet

    def send_json(self, command, sub_command, json_data=None):
        if not json_data:
            json_data = {}
        p = make_packet(command, sub_command, json_data, self._packet_for_send)
        self.send_packet(p)

    def send_packet(self, packet):
        logger.info("Sending packet {}".format(packet.data_dict()))
        self.sender.send_multipart([self.serial_int, packet.raw()])

    def shutdown(self):
        self.sender.shutdown()
        self.receiver.shutdown()
