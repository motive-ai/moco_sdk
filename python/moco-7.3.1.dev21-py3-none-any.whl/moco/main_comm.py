import argparse
import argcomplete
from moco.comm import Comm
import logging

from moco.packet import build_param_dict
from moco.util.logger import initialize_console_logging, set_process_name
from moco.params import load_config


logger = logging.getLogger(__name__)


class ArgParser(object):
    def __init__(self):
        logging.basicConfig(level=logging.INFO)
        set_process_name(__name__)
        initialize_console_logging()
        logging.getLogger('util.processmanager').setLevel(logging.INFO)

        args = self.parse_args()

        if args.config:
            config = load_config(args.config)
            logger.info("Loading config file '{}'".format(args.config))
        else:
            logger.info("Using default config")
            config = build_param_dict()

        if not args.serial:
            logger.info("Broadcasting to all boards")
            args.serial = [0xFEFE]
        if len(args.serial) == 1:
            self.board = Comm(args.serial[0], config, args.host, args.receive_port, args.send_port)
        else:
            self.board = [Comm(s, config, args.host, args.receive_port, args.send_port)
                          for s in args.serial]

    @staticmethod
    def create_parser():
        def formatter():
            return lambda prog: argparse.ArgumentDefaultsHelpFormatter(prog, max_help_position=60)

        arg_parser = argparse.ArgumentParser(description="Command line command sending",
                                             prog="send_cmd",
                                             formatter_class=formatter())
        arg_parser.add_argument('--version', '-v', action='version',
                                version='%(prog)s @WOC_VERSION_SEMVER@')
        arg_parser.add_argument('-s', '--serial', action='append', type=int,
                                help="Serial number to send to. Can be specified multiple times.")
        arg_parser.add_argument('--host', default='localhost', help='ZMQ server IP/hostname')
        arg_parser.add_argument('--receive_port', default=6510, help='ZMQ SUB port')
        arg_parser.add_argument('--send_port', default=6511, help='ZMQ PUB port')
        arg_parser.add_argument('-c', "--config", type=argparse.FileType('r'), default=None,
                                help="User config file")
        argcomplete.autocomplete(arg_parser)
        return arg_parser

    def parse_args(self, args_in=None, arg_parser=None):
        if arg_parser is None:
            arg_parser = self.create_parser()
        return arg_parser.parse_args(args_in)


if __name__ == '__main__':
    parser = ArgParser()
